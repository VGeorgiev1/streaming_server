var SIGNALING_SERVER = "http://localhost";
let screen = new  window.PublicConnection(SIGNALING_SERVER,null,'screen-share')